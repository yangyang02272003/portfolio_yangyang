// JavaScript Document

 $(document).ready(function() {
    $('.animsition').animsition();
  });